<?php
	require_once('wp_bootstrap_navwalker.php');

	function registrarMenuSuperior() {
		register_nav_menu('Menu-Superior', __('Menú Superior'));
	}
	add_action('init', 'registrarMenuSuperior');
	
?>