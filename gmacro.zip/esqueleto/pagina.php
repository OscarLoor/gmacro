<?php
/*
Template Name: Contacto
*/
?>
<?php get_header();?>
	<div id="tituloPrincipal" class="container-fluid contactoFoto">
		<div class="container">
			<div class="row">
				<h1><?php echo wp_title(''); ?></h1>
			</div>
		</div>
	</div>
	
	<div id="contenedorCirculoFoto" class="container-fluid">
			<div class="row">
				<img id="circuloFoto" src="<?php echo get_template_directory_uri();?>/img/circuloFoto.png">
			</div>

	</div>
	
	<div id="contenidoPrincipal" class="container-fluid">
		<div class="container">
			<div class="row contactoFila">
				<?php 
				if (have_posts()) :
				   while (have_posts()) :
				      the_post();
				      the_content();
				   endwhile;
				endif;
				?>
			</div>	
			
			
		</div>
	</div>


	
	<!--Google Map, cambiar la key-->
	<script type="text/javascript"
      src="http://maps.googleapis.com/maps/api/js?key=AIzaSyBggzMzBJgMg3k86bxBnZTzwxr9vTCFJ4s&sensor=TRUE&language=es&region=EC">
    </script>

	<div id="googleMapContacto" class="container-fluid">
			<div class="row">
					<div id="map_canvas" style="width:100%; height:400px"></div>
			</div>
	</div><!--googleMapContacto-->

	<div id="footer" class="container-fluid">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 col-md-3">
					<a href="#"><img src="<?php echo get_template_directory_uri();?>/img/logoBlanco.png"></a>
				</div>
				<div class="alineadoDerecha col-sm-12 col-md-7">
					<p>GRUPO MACRO -<span>DIVISIÓN PYMES</span></p>
					<p id="desarrollado">© 2015. Todos los derechos reservados. <a href="http://www.paginaswebenquito.ec">Desarrollado por: PáginasWebEnQuito.EC</a></p>
				</div>
				<div id="redesSociales" class="col-sm-12 col-md-2">
					<a href="#"><i class="fa fa-facebook"></i></a>
					<a href="#"><i class="fa fa-twitter"></i></a>
				</div>
			</div>
		</div>
	</div>

	<!--Jquery-->
	<script src="<?php echo get_template_directory_uri();?>/js/jquery-1.11.3.min.js"></script>
	<!--Cargo GSAP-->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.18.0/TweenMax.min.js"></script>
	<!--Cargo Bootstrap-->
	<script src="<?php echo get_template_directory_uri();?>/bootstrap/js/bootstrap.min.js"></script>
	<!--Scroll Magic-->
	<script src="<?php echo get_template_directory_uri();?>/js/ScrollMagic.min.js"></script>
	<!--Scroll Magic Propio-->
	<script src="<?php echo get_template_directory_uri();?>/js/scrollMagicPropio.js"></script>
	<!--Animaciones Propio-->
	<script src="<?php echo get_template_directory_uri();?>/js/animacionesPropio.js"></script>
	<!--Plugin Animation Gsap-->
	<script src="<?php echo get_template_directory_uri();?>/js/plugins_animationgsap.js"></script>
	<!--Google Map-->
	<script type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/googleMaps.js"></script>
  </body>
</html>