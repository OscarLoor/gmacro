<?php 
	wp_footer(); 
?>
<!--Google Map, cambiar la key-->
	<script type="text/javascript"
      src="http://maps.googleapis.com/maps/api/js?key=AIzaSyBggzMzBJgMg3k86bxBnZTzwxr9vTCFJ4s&sensor=TRUE&language=es&region=EC">
    </script>

	<div id="contenedorFooterInformacion" class="container-fluid">
		<div id="googleMapFooter" class="col-sm-6 col-xs-6 col-md-6">
			<div id="map_canvas" style="height:300px"></div>
		</div>
		<div id="informacionFooter" class="col-sm-6 col-xs-6 col-md-6">
			<div id="simulacionCelda">
				<h2>Datos de Contacto</h2>
				<p><i class="fa fa-map-marker"></i> El día N37-111 y El Mercurio, Quito</p>
				<p><i class="fa fa-phone"></i> PBX Ecuador (593 2) 224 01 79<br>(593 2)2 255 942</p>	
				<p><i class="fa fa-envelope"></i> info@gmacro.com</p>
				<p><i class="fa fa-skype"></i> gerencia-ecuador</p>
				<p><i class="fa fa-clock-o"></i> Lunes - Viernes 9:00 - 18:00</p>
			</div>
			
		</div>
	</div><!--container-fluid-->

	<div id="footer" class="container-fluid">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 col-md-3">
					<a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logoBlanco.png"></a>
				</div>
				<div class="alineadoDerecha col-sm-12 col-md-7">
					<p>GRUPO MACRO -<span>DIVISIÓN PYMES</span></p>
					<p id="desarrollado">© 2015. Todos los derechos reservados. <a href="http://www.paginaswebenquito.ec">Desarrollado por: PáginasWebEnQuito.EC</a></p>
				</div>
				<div id="redesSociales" class="col-sm-12 col-md-2">
					<a href="#"><i class="fa fa-facebook"></i></a>
					<a href="#"><i class="fa fa-twitter"></i></a>
				</div>
			</div>
		</div>
	</div>

	<!--Jquery-->
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/jquery-1.11.3.min.js"></script>
	<!--Cargo GSAP-->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.18.0/TweenMax.min.js"></script>
	<!--Cargo Bootstrap-->
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/bootstrap/js/bootstrap.min.js"></script>
	<!--Scroll Magic-->
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/ScrollMagic.min.js"></script>
	<!--Scroll Magic Propio-->
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/scrollMagicPropio.js"></script>
	<!--Animaciones Propio-->
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/animacionesPropio.js"></script>
	<!--Plugin Animation Gsap-->
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/plugins_animationgsap.js"></script>
	<!--Google Map-->
	<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/js/googleMaps.js"></script>
  </body>
</html>
