<?php get_header();?>
<div id="tituloPrincipal" class="container-fluid noticiaFoto">
		<div class="container">
			<div class="row">
				<h1><?php echo wp_title(''); ?></h1>
			</div>
		</div>
	</div>

	<div id="contenedorCirculoFoto" class="container-fluid">
			<div class="row">
				<img id="circuloFoto" src="<?php echo get_template_directory_uri();?>/img/circuloFoto.png">
			</div>

	</div>
	
	<div id="contenidoPrincipal" class="container-fluid">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<!--Nueva entrada-->
					 <!-- Start the Loop. -->
 					<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
 					
					<div class="col-md-6 nuevaEntrada">
						<div id="imagenNoticia" class="col-md-6">
							<?php if ( has_post_thumbnail() ) {
								the_post_thumbnail();
							}?>
						</div>

						<div class="col-md-6">
							<div id="categoria" class="col-md-12">
								<p class="postmetadata"><?php the_category( ', ' ); ?></p>
							</div>

							<div class="col-xs-3 col-sm-3 col-md-3 linea">
								
							</div>
							<div id="tituloNoticia" class="col-xs-12 col-sm-12 col-md-12">
								<h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="Link hacia <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
							</div>

							<div id="fechaNoticia" class="col-md-12">
								<small><?php the_time('F j, Y'); ?></small>
							</div>


						</div>
					</div><!--Fin Nueva Entrada-->
					<?php endwhile; else : ?>
					
				 	<p><?php _e( 'No existen noticias recientes.' ); ?></p>
				
				
				 	<!-- REALLY stop The Loop. -->
				 <?php endif; ?>
				</div>
				
				
				

				<div id="contenidoEntrada" class="col-md-12">
					<?php the_content();  ?>

				</div>
			</div>
		</div>
	</div>

<?php get_footer();?>