<?php get_header();?>
<?php
  if(is_front_page()){
?>
      <div id="myCarousel" class="carousel slide" data-ride="carousel">
					  <!-- Indicators -->
					  <ol class="carousel-indicators">
					    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
					    <li data-target="#myCarousel" data-slide-to="1"></li>
					    <li data-target="#myCarousel" data-slide-to="2"></li>
					    <li data-target="#myCarousel" data-slide-to="3"></li>
					  </ol>

					  <!-- Wrapper for slides -->
					  <div class="carousel-inner" role="listbox">
					    <div class="item active">
					      <img src="<?php echo get_template_directory_uri();?>/img/slideUno.png" alt="Chania">
					    </div>

					    <div class="item">
					      <img src="<?php echo get_template_directory_uri();?>/img/slideUno.png" alt="Chania">
					    </div>

					    <div class="item">
					      <img src="<?php echo get_template_directory_uri();?>/img/slideUno.png" alt="Flower">
					    </div>

					    <div class="item">
					      <img src="<?php echo get_template_directory_uri();?>/img/slideUno.png" alt="Flower">
					    </div>
					  </div>

					  <!-- Left and right controls -->
					  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
					    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
					    <span class="sr-only">Previous</span>
					  </a>
					  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
					    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
					    <span class="sr-only">Next</span>
					  </a>
					</div><!--myCarousel-->

	

	<div id="contenidoPrincipal" class="container-fluid">
		<div class="container">
			<div class="row">
				<div class="col-md-7">
					<div id="triggerClientes"></div>
					<h2>Nuestros <span>Clientes</span></h2>
					<img id="clientes" src="<?php echo get_template_directory_uri();?>/img/clientes.jpg">
				</div>

			</div>

			<div id="porqueElegirnos" class="row">
				<div class="col-md-8">
					<h2><i class="fa fa-angle-double-right"></i>¿Por qué <span>elegirnos</span>?</h2>
					<p id="parrafoServicios">Durante estos 15 años contribuimos con nuestros clientes en el desarrollo y la ejecución de programas de cambio de comportamiento organizacional en cuatro líneas de producto:</p>

					<div class="col-md-3">

						<img id="gamificando" src="<?php echo get_template_directory_uri();?>/img/gamificandoLogo.jpg">
					</div>

					<div class="col-md-9">
						<p><i class="fa fa-phone"></i> Servicio al cliente</p>
						<p><i class="fa fa-bar-chart"></i> Ventas</p>
						<p><i class="fa fa-users"></i> Liderazgo y trabajo en equipo</p>
						<p><i class="fa fa-globe"></i> Entendimiento intercultural e idiomas</p>
					</div>
				</div>
				<div class="col-md-4">
					<div id="triggerImagenEjecutivo"></div>
					<img id="ejecutivoDos" src="<?php echo get_template_directory_uri();?>/img/ejecutivoDos.jpg">
				</div>
			</div>

		</div>
	</div>
<?php
  }else{
?>
      
<div id="tituloPrincipal" class="container-fluid noticiaFoto">
		<div class="container">
			<div class="row">
				<h1> Noticias</h1>
				<p>Revisa nuestra sección de noticias para mantenerte informado sobre nuestra empresa</p>
			</div>

		</div>
	</div>
	<div id="contenedorCirculoFoto" class="container-fluid">
			<div class="row">
				<img id="circuloFoto" src="<?php echo get_template_directory_uri();?>/img/circuloFoto.png">
			</div>

	</div>
	
	<div id="contenidoPrincipal" class="container-fluid">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<!--Nueva entrada-->
					 <!-- Start the Loop. -->
 					<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
 					
					<div class="col-md-6 nuevaEntrada">
						<div id="imagenNoticia" class="col-md-6">
							<?php if ( has_post_thumbnail() ) {
								the_post_thumbnail();
							}?>
						</div>

						<div class="col-md-6">
							<div id="categoria" class="col-md-12">
								<p class="postmetadata"><?php the_category( ', ' ); ?></p>
							</div>

							<div class="col-xs-3 col-sm-3 col-md-3 linea">
								
							</div>
							<div id="tituloNoticia" class="col-xs-12 col-sm-12 col-md-12">
								<h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="Link hacia <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
							</div>

							<div id="fechaNoticia" class="col-md-12">
								<small><?php the_time('F j, Y'); ?></small>
							</div>

							<div id="leerMasNoticia" class="col-md-12">
								<a href="<?php echo get_permalink(); ?>"> LEER MÁS</a>
							</div>

						</div>
					</div><!--Fin Nueva Entrada-->
					<?php endwhile; else : ?>
					
				 	<p><?php _e( 'No existen noticias recientes.' ); ?></p>
				
				
				 	<!-- REALLY stop The Loop. -->
				 <?php endif; ?>
				</div>

				<div id="linkNavegacion" class="col-md-12">
					<?php next_posts_link('Noticias Anteriores <i class="fa fa-angle-double-right"></i>') ?>
<?php previous_posts_link('<i class="fa fa-angle-double-left"></i> Noticias Recientes') ?>
					 
				</div>
			</div>
		</div>
	</div>

 <?php }                     
?>


<?php get_footer();?>